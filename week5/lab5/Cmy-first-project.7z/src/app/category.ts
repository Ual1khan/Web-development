export interface Category{
    id:number;
    name:string;
}

export const CATEGORY: Category[] = [
{id:1, name:"Toys"},
{id:2, name:"Smartphones"},
{id:3, name:"Watches"},
{id:4, name:"HouseHold"}
];
